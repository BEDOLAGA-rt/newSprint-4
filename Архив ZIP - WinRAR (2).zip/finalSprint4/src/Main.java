public class Main {

    public static void main(String[] args) {

        TaskManager taskManager = new TaskManager();


        Task washFloor = new Task("Протереть пыль", "В своей комнате");
        Task washFloorCreated = taskManager.addTask(washFloor);
        System.out.println(washFloorCreated);

        Task washFloorToUpdate = new Task(washFloor.getId(), "Помыть посуду", "До прихода мамы",
                Status.IN_PROGRESS);
        Task washFloorUpdated = taskManager.updateTask(washFloorToUpdate);
        System.out.println(washFloorUpdated);


        Epic flatRenovation = new Epic("Сделать перестановку", "Нужно успеть пока зп не закончилась");
        taskManager.addEpic(flatRenovation);
        System.out.println(flatRenovation);
        Subtask flatRenovationSubtask1 = new Subtask("Поклеить обои", "Спросить какие",
                flatRenovation.getId());
        Subtask flatRenovationSubtask2 = new Subtask("Установить новую тумбочку", "Найти ее для начала",
                flatRenovation.getId());
        taskManager.addSubtask(flatRenovationSubtask1);
        taskManager.addSubtask(flatRenovationSubtask2);
        System.out.println(flatRenovation);
        flatRenovationSubtask2.setStatus(Status.DONE);
        taskManager.updateSubtask(flatRenovationSubtask2);
        System.out.println(flatRenovation);
    }
}